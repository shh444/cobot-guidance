# 문서 수정 가이드

이 프로젝트는 **Sphinx + MyST Markdown** 기반입니다. 즉, 대부분의 수정은 Word나 전용 편집기가 아니라 **Markdown 파일과 CSS 파일**만 바꾸면 됩니다.

이번 버전은 특히 디자인을 쉽게 바꾸려고 파일을 **3층 구조**로 나눴습니다.

- **내용**: `docs/**/*.md`
- **색상 프리셋**: `docs/_static/theme-presets.css`
- **레이아웃/카드/버튼 스타일**: `docs/_static/custom.css`

## 가장 빠른 수정 방법

1. `docs/` 폴더 안에서 바꾸고 싶은 `.md` 파일을 연다.
2. 문장을 수정하거나 표, 코드 블록, 이미지를 추가한다.
3. 터미널에서 HTML을 다시 빌드한다.
4. `docs/_build/html/index.html`을 새로고침한다.

라이브 리로드로 작업하면 훨씬 편합니다.

```bash
sphinx-autobuild docs docs/_build/html --port 3000
```

## 어디를 수정해야 하나?

| 바꾸고 싶은 것 | 수정 파일 |
| --- | --- |
| 첫 화면 문구 / 카드 | `docs/index.md` |
| 각 장 본문 | `docs/start/*.md`, `docs/basics/*.md` 등 |
| 상단/사이드 메뉴 구조 | `docs/index.md` 안의 `toctree` |
| 프리셋 색상 | `docs/_static/theme-presets.css` |
| 카드 / 버튼 / 표 / 코드 블록 / 여백 | `docs/_static/custom.css` |
| 프리셋 선택기 동작 | `docs/_static/theme-switcher.js` |
| 테마 설정 | `docs/conf.py` |
| 로고 / 파비콘 | `docs/_static/robot-manual-logo.svg` |
| 이미지 추가 | `docs/_static/img/` |

## 새 페이지 추가하기

예를 들어 `안전 입문` 장을 하나 더 만들고 싶다면 이렇게 하면 됩니다.

### 1) 파일 만들기

`docs/start/safety-basics.md`

```md
# 안전 입문

이 장에서는 협동로봇을 처음 다룰 때 반드시 확인해야 하는 안전 포인트를 정리합니다.

## 핵심 체크

- 비상정지 위치 확인
- 보호정지 발생 시 대응 순서 확인
- 저속 검증 절차 확인
```

### 2) 메뉴에 연결하기

`docs/index.md`의 `시작하기` toctree에 아래 한 줄을 추가합니다.

```md
start/safety-basics
```

### 3) 빌드하기

Windows:

```powershell
.\make.bat html
```

macOS / Linux:

```bash
make html
```

### 4) 결과 확인하기

`docs/_build/html/index.html`을 열면 왼쪽 메뉴에 새 장이 나타납니다.

## 문장만 바꾸는 경우

예를 들어 `docs/motion/tcp.md` 파일에서 문장을 바로 고치면 됩니다.

```md
## 왜 TCP가 중요한가?

TCP가 잘못되면 MoveL 경로, Feature teaching, 위치변수이동 결과가 모두 어긋날 수 있습니다.
```

즉, **대부분의 내용 수정은 Markdown만 고치면 끝**입니다.

## 이미지 넣는 방법

### 1) 이미지 파일 복사

예: `docs/_static/img/tcp-setting-screen.png`

### 2) 본문에 삽입

```md
![TCP 설정 예시 화면](_static/img/tcp-setting-screen.png)
```

하위 폴더 문서에서 이미지를 넣을 때는 상대 경로를 맞춰야 합니다.

예: `docs/motion/tcp.md`에서는

```md
![TCP 설정 예시 화면](../_static/img/tcp-setting-screen.png)
```

## 내부 링크 거는 방법

다른 장으로 연결하려면 `doc` 역할을 쓰는 것이 가장 편합니다.

```md
자세한 내용은 {doc}`../motion/tcp` 장을 참고하세요.
```

## 디자인을 바꾸고 싶을 때

### 1) 색감만 바꾸고 싶다

`docs/_static/theme-presets.css`

여기에는 프리셋별 색상 토큰이 들어 있습니다.

```css
html[data-brand-preset="indigo"] {
  --brand-950: 30 27 75;
  --brand-700: 67 56 202;
  --brand-500: 99 102 241;
  --accent-500: 14 165 233;
}
```

이 숫자들만 바꿔도 버튼, 링크, 카드 포인트 색, 홈 히어로, 강조선이 거의 같이 바뀝니다.

### 2) 카드 모양이나 여백을 바꾸고 싶다

`docs/_static/custom.css`

여기서 아래 요소를 조정합니다.

- 첫 화면 hero 영역
- 카드 둥근 모서리 / 그림자
- 제목 크기와 간격
- 표 스타일
- 코드 블록 스타일
- 헤더 / 사이드바 / 배경 톤
- 테마 플로팅 버튼 모양

### 3) 프리셋 종류나 기본값을 바꾸고 싶다

`docs/_static/theme-switcher.js`

- `DEFAULT_PRESET`을 바꾸면 기본 테마 변경
- `PRESETS`에 항목을 추가하면 새 프리셋 추가

## 디자인을 실제로 돌려보는 방법

이 프로젝트에는 오른쪽 아래에 **🎨 테마 버튼**이 붙어 있습니다. 여기서 프리셋을 눌러서 바로 비교할 수 있습니다.

더 체계적으로 보려면 `appendix/design-lab.md` 페이지를 열어 보세요.

## 로컬에서 계속 수정하면서 미리보기 하는 법

가장 편한 방식은 `sphinx-autobuild`를 쓰는 것입니다.

```bash
pip install -r requirements.txt
sphinx-autobuild docs docs/_build/html --port 3000
```

원하는 포트가 있으면 3000 대신 8080, 9000, 5500 등으로 바꾸면 됩니다.

## 회사용으로 바꿀 때 추천하는 순서

1. 메인 화면 문구를 회사 교육 흐름에 맞게 수정
2. 실제 장비 사진과 티치 펜던트 캡처 추가
3. TCP / Feature / I/O 명명 규칙 반영
4. PLC / 비전 / 상위 PC 통신 예제 반영
5. 디자인 프리셋 중 하나를 기본값으로 고정
6. 트러블슈팅 장에 현장 에러 사례 누적

## 자주 묻는 질문

### Markdown을 전혀 몰라도 수정할 수 있나?

가능합니다. 제목(`#`), 소제목(`##`), 목록(`-`) 정도만 알아도 대부분 수정할 수 있습니다.

### 여러 사람이 같이 디자인을 만지면 어디만 건드리면 되나?

보통 역할을 이렇게 나누면 깔끔합니다.

- 내용 담당: `docs/**/*.md`
- 브랜드 컬러 담당: `theme-presets.css`
- 레이아웃 담당: `custom.css`

### 프리셋 선택기가 싫으면 없앨 수 있나?

가능합니다. `docs/conf.py`의 `html_js_files`에서 `theme-switcher.js`를 빼면 됩니다.

### 색은 괜찮은데 배경이 너무 화려하면?

`custom.css` 맨 위 `body`의 `radial-gradient(...)` 두 줄을 약하게 줄이거나 지우면 됩니다.
