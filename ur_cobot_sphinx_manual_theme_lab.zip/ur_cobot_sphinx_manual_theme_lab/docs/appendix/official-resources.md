# 공식 자료 링크

사내 매뉴얼은 결국 최신 공식 자료와 연결되어 있어야 유지보수가 쉽습니다. 아래 링크들은 내부 문서 하단에 "공식 참고 자료"로 넣기 좋은 항목들입니다.

## 문서 허브

- [Universal Robots Documentation Landing Page](https://docs.universal-robots.com/)
  - 전체 문서 허브. PolyScope 5, PolyScope X, tutorials, drivers 등 시작점으로 좋습니다.

- [Universal Robots Manuals](https://www.universal-robots.com/manuals/)
  - PDF/HTML 매뉴얼, 각종 자료 모음입니다.

## 튜토리얼

- [PolyScope Tutorials](https://docs.universal-robots.com/tutorials/)
  - 공식 튜토리얼 메인 페이지

- [URScript Tutorials](https://docs.universal-robots.com/tutorials/urscript-tutorials.html)
  - URScript 관련 공식 튜토리얼 모음

- [Communication Protocol Tutorials](https://docs.universal-robots.com/tutorials/communication-protocol-tutorials.html)
  - Dashboard, Primary/Secondary, RTDE, Socket 등 통신 튜토리얼 모음

## 통신 관련 직접 링크

- [Dashboard Server e-Series, port 29999](https://www.universal-robots.com/articles/ur/dashboard-server-e-series-port-29999/)
- [Primary and Secondary Interfaces](https://docs.universal-robots.com/tutorials/communication-protocol-tutorials/primary-secondary-guide.html)
- [RTDE Guide](https://docs.universal-robots.com/tutorials/communication-protocol-tutorials/rtde-guide.html)
- [TCP/IP Socket Communication via URScript](https://docs.universal-robots.com/tutorials/communication-protocol-tutorials/tcp-ip-client.html)

## PolyScope / 사용 설명서

- [PolyScope 5 Online Documentation](https://www.universal-robots.com/manuals/EN/HTML/SW5_20/Content/Landingpages/Web/HomePoly5.htm)
- [Support / Downloads](https://www.universal-robots.com/support/)
- [UR Download](https://www.universal-robots.com/download/)

## 내부 문서에 넣는 방식 추천

공식 링크는 그냥 나열하지 말고 아래처럼 목적과 함께 적는 것이 좋습니다.

| 링크 | 왜 보는가 | 내부 문서 연결 위치 |
| --- | --- | --- |
| Manuals | 최신 사용자 설명서 확인 | 시작하기 / 안전 |
| Tutorials | 개발/통신 가이드 확인 | 자동화 확장 |
| Dashboard Article | 원격 실행 명령 확인 | Dashboard 장 |
| RTDE Guide | 상태 모니터링 구조 확인 | RTDE 장 |

## 유지보수 팁

- 화면 캡처는 내부 문서에 넣고, 세부 스펙은 공식 링크로 연결
- 버전이 바뀌면 "대상 버전" 문구부터 수정
- 사내 FAQ가 생기면 공식 문서 링크와 함께 정리

:::{tip}
공식 문서를 그대로 번역해 넣기보다, 내부 문서에는 "우리 설비에서 어떻게 해석하는지"를 덧붙이는 편이 훨씬 유용합니다.
:::
