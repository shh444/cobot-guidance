# 디자인 실험실

<div class="lab-banner">
  <span class="lab-kicker">Live Theme Playground</span>
  <h2>색감과 카드 스타일을 바로 돌려보세요</h2>
  <p>
    아래 프리셋을 누르면 홈 화면, 본문 카드, 코드 블록, 버튼, 표 스타일이 즉시 바뀝니다.
    선택한 프리셋은 브라우저에 저장되므로 다른 페이지로 넘어가도 유지됩니다.
  </p>
</div>

<p>
현재 선택된 프리셋: <strong data-current-preset-label>Indigo Flow</strong>
</p>

<div class="preset-grid">
  <button class="preset-tile" type="button" data-preset="indigo">
    <span class="preset-name">Indigo Flow</span>
    <span class="preset-desc">기술 문서에 가장 무난한 기본형. 차분한 인디고와 청량한 시안 포인트를 사용합니다.</span>
    <span class="swatch-row">
      <span class="color-dot" style="background:#4338ca"></span>
      <span class="color-dot" style="background:#6366f1"></span>
      <span class="color-dot" style="background:#0ea5e9"></span>
    </span>
  </button>
  <button class="preset-tile" type="button" data-preset="emerald">
    <span class="preset-name">Emerald Field</span>
    <span class="preset-desc">생산라인 문서나 설비 표준서에 잘 어울리는 안정적인 그린-시안 조합입니다.</span>
    <span class="swatch-row">
      <span class="color-dot" style="background:#047857"></span>
      <span class="color-dot" style="background:#10b981"></span>
      <span class="color-dot" style="background:#06b6d4"></span>
    </span>
  </button>
  <button class="preset-tile" type="button" data-preset="graphite">
    <span class="preset-name">Graphite Amber</span>
    <span class="preset-desc">산업 장비 느낌이 강한 묵직한 계열. 회색-앰버 톤이라 현장 장비 사진과도 잘 맞습니다.</span>
    <span class="swatch-row">
      <span class="color-dot" style="background:#78350f"></span>
      <span class="color-dot" style="background:#d97706"></span>
      <span class="color-dot" style="background:#f59e0b"></span>
    </span>
  </button>
  <button class="preset-tile" type="button" data-preset="orchid">
    <span class="preset-name">Orchid Pulse</span>
    <span class="preset-desc">조금 더 현대적이고 눈에 띄는 스타일. 내부 교육 포털이나 데모 사이트에 잘 어울립니다.</span>
    <span class="swatch-row">
      <span class="color-dot" style="background:#9333ea"></span>
      <span class="color-dot" style="background:#c084fc"></span>
      <span class="color-dot" style="background:#ec4899"></span>
    </span>
  </button>
  <button class="preset-tile" type="button" data-preset="mono">
    <span class="preset-name">Mono Slate</span>
    <span class="preset-desc">최대한 절제된 회색 기반 스타일. 문서가 과하게 화려해 보이는 것이 싫을 때 좋습니다.</span>
    <span class="swatch-row">
      <span class="color-dot" style="background:#111827"></span>
      <span class="color-dot" style="background:#374151"></span>
      <span class="color-dot" style="background:#9ca3af"></span>
    </span>
  </button>
</div>

## 내가 직접 수정할 때 보는 파일

| 바꾸고 싶은 것 | 수정 파일 |
| --- | --- |
| 프리셋 색상 | `docs/_static/theme-presets.css` |
| 카드, 버튼, 표, 코드 블록 모양 | `docs/_static/custom.css` |
| 프리셋 선택기 동작 | `docs/_static/theme-switcher.js` |
| 홈 화면 카드 / 문구 | `docs/index.md` |

## 제일 빨리 디자인 테스트하는 방법

1. 터미널에서 `sphinx-autobuild docs docs/_build/html --port 3000` 실행
2. 브라우저에서 로컬 주소 열기
3. `theme-presets.css`를 열고 색 숫자만 조금씩 수정
4. 저장할 때마다 자동 새로고침으로 결과 확인

## 색상만 바꾸고 싶다면

`theme-presets.css`에는 프리셋별로 아래처럼 색 토큰이 분리돼 있습니다.

```css
html[data-brand-preset="emerald"] {
  --brand-950: 6 78 59;
  --brand-700: 4 120 87;
  --brand-500: 16 185 129;
  --accent-500: 6 182 212;
  --accent-300: 103 232 249;
  --surface-accent: 236 253 245;
}
```

여기 숫자만 바꿔도 사이트 전체 색감이 거의 동시에 바뀝니다.

## 기본 프리셋을 바꾸고 싶다면

`docs/_static/theme-switcher.js`에서 아래 값을 바꾸면 됩니다.

```js
const DEFAULT_PRESET = "indigo";
```

예를 들어 기본값을 `graphite`로 하고 싶으면 다음처럼 바꿉니다.

```js
const DEFAULT_PRESET = "graphite";
```

## 프리셋을 하나 더 추가하고 싶다면

### 1) `theme-presets.css`에 새 블록 추가

```css
html[data-brand-preset="copper"] {
  --brand-950: 67 20 7;
  --brand-700: 154 52 18;
  --brand-500: 249 115 22;
  --accent-500: 251 191 36;
  --accent-300: 253 224 71;
  --surface-accent: 255 247 237;
}
```

### 2) `theme-switcher.js`의 `PRESETS`에 추가

```js
copper: {
  label: "Copper Line",
  desc: "주황-골드 계열",
  swatches: ["#9a3412", "#f97316", "#fbbf24"],
},
```

### 3) 이 페이지에 버튼 하나 추가

`appendix/design-lab.md`의 프리셋 버튼 블록을 하나 복사해서 `data-preset="copper"`로 바꾸면 끝입니다.

## 구조를 크게 바꾸고 싶다면

색은 괜찮은데 카드 둥근 모서리, 그림자, 여백, 제목 크기, 헤더 투명도 같은 게 마음에 안 들면 `custom.css`를 보세요.

예를 들어 카드 라운드를 줄이려면 아래 부분을 수정하면 됩니다.

```css
:root {
  --radius-md: 22px;
  --radius-lg: 28px;
  --radius-xl: 34px;
}
```

## 추천 조합

- **회사 내부 교육 문서** → `Indigo Flow`, `Emerald Field`
- **장비 카탈로그 / 산업 현장 느낌** → `Graphite Amber`
- **데모 사이트 / 신입 교육 포털** → `Orchid Pulse`
- **최대한 절제된 문서** → `Mono Slate`

:::{tip}
테마를 고를 때는 홈 화면만 보지 말고, **표 / 코드 블록 / admonition / 긴 본문**까지 같이 확인하세요. 실제 사용감은 이 요소들에서 차이가 크게 납니다.
:::
