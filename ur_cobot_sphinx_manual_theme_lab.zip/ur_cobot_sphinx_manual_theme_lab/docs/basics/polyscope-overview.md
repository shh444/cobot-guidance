# PolyScope 개요

:::{admonition} 이 장에서 배우는 것
:class: note
- PolyScope를 처음 봤을 때 어디부터 보면 되는지
- Installation / Program / Run / Move / I/O / Log의 역할
- 메뉴가 많아도 길을 잃지 않는 기본 원리
:::

## PolyScope를 한 문장으로 설명하면

PolyScope는 **로봇을 설정하고, 움직임을 가르치고, 실행하고, 상태를 확인하는 작업 화면**입니다.

초보자는 메뉴 이름을 외우기보다 다음 두 문장을 기억하면 됩니다.

- **Installation은 로봇이 어떤 조건에서 움직일지 정하는 곳**
- **Program은 로봇이 무엇을 할지 정하는 곳**

이 두 개만 구분해도 절반은 이해한 셈입니다.

## 화면을 기능으로 나눠 보기

| 영역 | 초보자용 해석 | 대표 작업 |
| --- | --- | --- |
| Installation | 로봇의 기본 설정 | TCP, Payload, Feature, I/O, 네트워크 |
| Program | 작업 순서 만들기 | Move, Waypoint, If, Loop, Script |
| Run | 실행과 모니터링 | 재생, 일시정지, 정지, 상태 확인 |
| Move | teaching / 조그 | 점 잡기, 좌표 읽기, Freedrive |
| I/O | 신호 확인 | 센서 입력, 출력 상태 확인 |
| Log / 메시지 | 문제 파악 | 경고, 에러, 보호정지 원인 확인 |

## 가장 중요한 구분: Installation vs Program

### Installation

Installation은 프로그램 여러 개가 공통으로 쓰는 **환경 설정**입니다.

예를 들면:

- TCP
- Payload
- Feature
- I/O 이름
- 통신 설정
- 일부 안전 관련 설정

### Program

Program은 실제 작업 순서입니다.

예를 들면:

- 시작 위치로 이동
- 그리퍼 닫기
- MoveL로 삽입
- 센서 확인
- 배출 위치로 이동

:::{important}
초보자가 많이 헷갈리는 부분은 "왜 다른 프로그램에서도 같은 TCP가 보이지?" 입니다. 이유는 TCP가 보통 Installation에 속하기 때문입니다.
:::

## Program Tree를 보는 법

Program Tree는 "로봇이 어떤 순서로 무엇을 할지"를 보여 줍니다.

보통은 아래처럼 읽으면 됩니다.

1. 루트에서 시작
2. 상위 노드(예: Move, If, Loop)가 큰 문맥을 만든다
3. Waypoint, Set, Wait 같은 하위 노드가 실제 동작을 채운다

예시:

```text
Robot Program
  BeforeStart
  MoveJ
    home_safe
  MoveL
    approach_pick
    pick
  Set
    gripper_close
```

## Move 화면을 어떻게 써야 하나

Move 화면은 초보자에게 매우 중요합니다. 이유는 이곳이 **좌표와 실제 움직임이 만나는 장소**이기 때문입니다.

여기서 보게 되는 핵심은 다음과 같습니다.

- 현재 TCP 위치
- 기준 좌표(Base / Tool / Feature)
- 조그 이동
- Freedrive
- teaching용 자세 조정

## Run 화면에서 봐야 할 것

초보자는 Run 화면에서 아래 4가지만 먼저 보세요.

- 프로그램이 실제로 어디까지 진행됐는가
- 속도 스케일이 얼마인가
- 현재 멈춤/일시정지/실행 상태가 무엇인가
- 알람이나 경고가 떴는가

## I/O 화면의 역할

I/O 화면은 단순한 디버그 화면이 아니라, **외부 장치와 로봇이 대화하고 있는지 확인하는 곳**입니다.

예를 들어 아래를 빠르게 확인할 수 있어야 합니다.

- 시작 버튼이 정말 들어오는가
- 그리퍼 출력이 실제로 켜졌는가
- 센서가 예상한 타이밍에 변하는가

## PolyScope X 차이 메모

PolyScope X에서는 화면 구성과 아이콘 위치가 다를 수 있습니다. 하지만 여전히 핵심은 같습니다.

- 설정할 것: Installation 성격
- 순서 만들 것: Program 성격
- 실행 확인: Run 성격
- 좌표 teaching: Move 성격

즉, **화면이 달라도 기능 분류는 같다**고 보면 됩니다.

## 초보자가 자주 하는 실수

### Installation과 Program을 같이 저장하지 않음
나중에 다른 PC나 다른 로봇에서 불러오면 TCP/Feature가 달라져서 문제가 생길 수 있습니다.

### Move 화면에서 본 좌표와 프로그램 기준 Feature가 다름
지금 보고 있는 좌표계와 실제 Move 노드의 기준이 다르면 teaching 감각이 꼬입니다.

### I/O 확인 없이 프로그램만 고침
문제가 움직임이 아니라 신호일 수 있는데, 프로그램만 계속 수정하게 됩니다.

## 체크리스트

- [ ] Installation과 Program 차이를 설명할 수 있다
- [ ] Program Tree를 위에서 아래로 읽을 수 있다
- [ ] Move 화면에서 기준 좌표를 바꿔 볼 수 있다
- [ ] I/O 화면에서 입력/출력을 확인할 수 있다

## 다음에 읽을 장

다음 장에서는 **정말로 첫 프로그램**을 만들어 봅니다.
