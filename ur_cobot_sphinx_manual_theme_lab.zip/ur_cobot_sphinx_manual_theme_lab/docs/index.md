# UR 협동로봇 입문 웹 매뉴얼

<section class="landing-hero">
  <div class="hero-copy">
    <p class="hero-eyebrow">Universal Robots · Learn by Doing</p>
    <p class="hero-title">처음 만지는 사람도<br>순서대로 따라갈 수 있는<br>UR 협동로봇 웹 매뉴얼</p>
    <p class="hero-subtitle">
      협동로봇 개요부터 PolyScope, Waypoint, TCP, Feature, Payload, URScript, 통신까지,
      입문자가 실제 작업 흐름대로 이해할 수 있게 구성한 학습형 Sphinx 문서입니다.
    </p>
    <div class="hero-actions">
      <a class="button-link primary" href="start/cobot-overview.html">문서 시작하기</a>
      <a class="button-link secondary" href="appendix/design-lab.html">디자인 실험실</a>
      <a class="button-link secondary" href="appendix/editing-guide.html">수정 가이드</a>
    </div>
  </div>
  <aside class="hero-panel">
    <p class="panel-label">추천 루트</p>
    <ol class="hero-list">
      <li>
        <span class="hero-step">1</span>
        <div>
          <strong>개념 먼저 잡기</strong>
          <p>협동로봇이 무엇인지, PolyScope 5와 X가 어떻게 다른지, URSim으로 어디까지 연습할 수 있는지부터 이해합니다.</p>
        </div>
      </li>
      <li>
        <span class="hero-step">2</span>
        <div>
          <strong>직접 움직여 보기</strong>
          <p>하드웨어, PolyScope 화면, 첫 프로그램, Waypoint와 MoveJ / MoveL 감각을 먼저 익힙니다.</p>
        </div>
      </li>
      <li>
        <span class="hero-step">3</span>
        <div>
          <strong>기준 좌표 잡기</strong>
          <p>TCP, Base / Tool / Feature를 이해한 다음, 위치변수이동으로 프로그램을 유연하게 만듭니다.</p>
        </div>
      </li>
      <li>
        <span class="hero-step">4</span>
        <div>
          <strong>자동화로 확장하기</strong>
          <p>Payload, 특이점, URScript, Dashboard, Socket, RTDE를 연결해 실제 설비 흐름으로 확장합니다.</p>
        </div>
      </li>
    </ol>
  </aside>
</section>

<div class="hero-stat-strip">
  <div class="hero-stat">
    <strong>5개 프리셋</strong>
    <span>Indigo / Emerald / Graphite / Orchid / Mono</span>
  </div>
  <div class="hero-stat">
    <strong>17개 문서</strong>
    <span>초보자 학습 장 + 부록 레퍼런스</span>
  </div>
  <div class="hero-stat">
    <strong>Markdown 기반</strong>
    <span>VS Code에서 바로 수정 가능한 구조</span>
  </div>
  <div class="hero-stat">
    <strong>현장 확장 가능</strong>
    <span>TCP, I/O, 통신 규칙을 사내 표준으로 덧붙이기 쉬움</span>
  </div>
</div>

:::{note}
이 문서는 **입문용 / 내부 교육용 초안**입니다. 실제 설비에 반영할 때는 사용 중인 소프트웨어 버전의 공식 설명서, 안전 문서, 그리고 현장 위험성 평가 결과를 함께 확인하세요.
:::

## 문서 한눈에 보기

<p class="section-intro">
왼쪽 사이드바로 순서대로 읽어도 되고, 아래 카드에서 바로 필요한 장으로 들어가도 됩니다.
그리고 오른쪽 아래 <strong>🎨 테마 버튼</strong>으로 색감을 즉시 바꿔볼 수 있습니다.
</p>

<div class="card-grid">
  <a class="doc-card" href="start/cobot-overview.html">
    <span class="card-kicker">Step 01</span>
    <h3>시작하기</h3>
    <p>협동로봇 개요, 버전 구분, URSim으로 입문 경로를 잡습니다.</p>
    <span class="card-meta">협동로봇 · PolyScope 5 / X · URSim</span>
  </a>
  <a class="doc-card" href="basics/hardware.html">
    <span class="card-kicker">Step 02</span>
    <h3>기본 조작</h3>
    <p>하드웨어, PolyScope, 첫 프로그램을 통해 장비 앞에서 무엇을 봐야 하는지 익힙니다.</p>
    <span class="card-meta">하드웨어 · 펜던트 · Program Tree</span>
  </a>
  <a class="doc-card" href="motion/waypoints-and-moves.html">
    <span class="card-kicker">Step 03</span>
    <h3>모션과 좌표</h3>
    <p>Waypoint, MoveJ / MoveL / MoveP, TCP, Feature, 위치변수이동을 연결해서 이해합니다.</p>
    <span class="card-meta">Waypoint · TCP · Feature · Pose</span>
  </a>
  <a class="doc-card" href="stability/payload-and-cog.html">
    <span class="card-kicker">Step 04</span>
    <h3>안정 운전</h3>
    <p>Payload / CoG와 특이점을 통해 프로그램이 왜 불안정해지는지 원인을 잡습니다.</p>
    <span class="card-meta">Payload · CoG · Singularity</span>
  </a>
  <a class="doc-card" href="automation/urscript-basics.html">
    <span class="card-kicker">Step 05</span>
    <h3>자동화 확장</h3>
    <p>URScript, Dashboard, Socket, RTDE를 통해 외부 장비와 연결하는 입문 지점을 만듭니다.</p>
    <span class="card-meta">URScript · Socket · RTDE</span>
  </a>
  <a class="doc-card" href="appendix/design-lab.html">
    <span class="card-kicker">Theme Lab</span>
    <h3>디자인 실험실</h3>
    <p>5가지 프리셋을 눌러가며 카드, 버튼, 코드 블록, 배경 톤을 바로 테스트해볼 수 있습니다.</p>
    <span class="card-meta">Live preset switcher · CSS variable 구조</span>
  </a>
  <a class="doc-card" href="appendix/editing-guide.html">
    <span class="card-kicker">Guide</span>
    <h3>문서 수정 가이드</h3>
    <p>본문, 메뉴, 색상, 레이아웃을 어디서 수정하면 되는지 한 페이지로 정리했습니다.</p>
    <span class="card-meta">index.md · theme-presets.css · custom.css</span>
  </a>
</div>

## 추천 학습 순서

<p class="section-intro">
처음 배우는 사람은 아래 4단계만 기억하면 됩니다. <strong>켜기 → 움직이기 → 기준 잡기 → 자동화 연결</strong>입니다.
</p>

<div class="path-grid">
  <div class="path-step">
    <span class="path-number">1</span>
    <h3>켜기</h3>
    <p>하드웨어와 PolyScope 화면을 먼저 익혀야 어떤 상태인지 읽을 수 있습니다.</p>
  </div>
  <div class="path-step">
    <span class="path-number">2</span>
    <h3>움직이기</h3>
    <p>첫 프로그램과 Waypoint / MoveJ / MoveL을 통해 이동 감각을 먼저 만듭니다.</p>
  </div>
  <div class="path-step">
    <span class="path-number">3</span>
    <h3>기준 잡기</h3>
    <p>TCP와 Feature를 이해하면 위치변수이동과 재사용 가능한 프로그램이 쉬워집니다.</p>
  </div>
  <div class="path-step">
    <span class="path-number">4</span>
    <h3>연결하기</h3>
    <p>Payload / 특이점 / URScript / 통신을 묶으면 현장 자동화에 직접 이어집니다.</p>
  </div>
</div>

## 디자인을 직접 돌려보는 방법

<div class="page-section-grid">
  <div class="page-section-card">
    <h3>브라우저에서 바로</h3>
    <p>오른쪽 아래 <strong>🎨 테마</strong> 버튼을 눌러서 프리셋을 즉시 바꿔볼 수 있습니다. 선택한 프리셋은 브라우저에 저장돼서 다른 페이지로 이동해도 그대로 유지됩니다.</p>
  </div>
  <div class="page-section-card">
    <h3>CSS를 직접 수정</h3>
    <p><code>docs/_static/theme-presets.css</code>는 색상 토큰, <code>docs/_static/custom.css</code>는 카드와 레이아웃을 담당합니다. 저장하면 <code>sphinx-autobuild</code>로 바로 미리볼 수 있습니다.</p>
  </div>
</div>

<div class="quick-edit-box">
  <p><strong>추천 워크플로</strong>: <code>sphinx-autobuild docs docs/_build/html --port 3000</code>으로 띄운 다음, <code>theme-presets.css</code>를 열고 색을 조금씩 바꿔보세요. 저장할 때마다 브라우저가 자동 갱신됩니다.</p>
</div>

## 이 문서를 사내 문서로 바꾸는 방법

<div class="editing-grid">
  <div class="editing-card">
    <p class="editing-kicker">Content</p>
    <h3>내용은 Markdown으로 수정</h3>
    <p><code class="literal">docs/start</code>, <code class="literal">docs/basics</code>처럼 섹션별 폴더 안의 <code class="literal">.md</code> 파일을 고치면 됩니다.</p>
    <span class="editing-meta">본문 수정 · 체크리스트 추가 · 실습 예제 교체</span>
  </div>
  <div class="editing-card">
    <p class="editing-kicker">Style</p>
    <h3>디자인은 토큰 + 레이아웃으로 수정</h3>
    <p>색상은 <code class="literal">theme-presets.css</code>, 카드/버튼/여백은 <code class="literal">custom.css</code>에서 바꾸면 됩니다.</p>
    <span class="editing-meta">브랜드 컬러 · 카드 UI · 반응형 레이아웃</span>
  </div>
</div>

<div class="editing-note">
  <p><strong>메뉴를 바꾸고 싶다면</strong> <code class="literal">docs/index.md</code>의 숨김 <code class="literal">toctree</code>를 수정하세요. 새 페이지를 추가했다면 홈 카드 링크도 같이 업데이트하면 됩니다.</p>
</div>

<p class="footer-note">
자세한 편집 방법은 <a href="appendix/editing-guide.html">문서 수정 가이드</a>와 <a href="appendix/design-lab.html">디자인 실험실</a>에 정리해 두었습니다.
</p>

```{toctree}
:hidden:
:maxdepth: 2
:caption: 시작하기

start/cobot-overview
start/version-and-learning-path
start/ursim-first
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 기본 조작

basics/hardware
basics/polyscope-overview
basics/first-program
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 모션과 좌표

motion/waypoints-and-moves
motion/tcp
motion/frames-and-features
motion/variable-position-moves
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 안정 운전

stability/payload-and-cog
stability/singularity
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 자동화 확장

automation/urscript-basics
automation/communication-overview
automation/dashboard-server
automation/socket-communication
automation/rtde
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 부록

appendix/glossary
appendix/ports-and-interfaces
appendix/troubleshooting
appendix/official-resources
appendix/design-lab
appendix/editing-guide
```
