# UR 협동로봇 입문 웹 매뉴얼

처음 Universal Robots 협동로봇을 접하는 작업자와 엔지니어를 위해 만든 **학습형 Sphinx 웹 문서**입니다.

이 문서는 아래 질문에 답하도록 설계했습니다.

- 로봇을 어떻게 켜고, 어떤 화면에서 무엇을 해야 하나?
- MoveJ / MoveL / Waypoint는 어떻게 연결되나?
- TCP와 Feature를 왜 잡아야 하나?
- 위치변수이동은 언제 쓰고, 어떤 실수를 많이 하나?
- 페이로드와 특이점은 왜 프로그램 품질에 큰 영향을 주나?
- URScript와 통신은 어디서부터 시작하면 좋나?

:::{note}
이 문서는 **입문용/내부 교육용 초안**입니다. 실제 설비 반영 전에는 반드시 사용 중인 소프트웨어 버전의 공식 설명서, 안전 문서, 그리고 현장 위험성 평가 결과를 함께 확인하세요.
:::

## 이 문서의 사용법

- **처음 배우는 사람**: `시작하기 -> 기본 조작 -> 모션과 좌표 -> 안정 운전 -> 자동화 확장` 순서로 읽기
- **현장 실무자**: 왼쪽 메뉴에서 필요한 장만 바로 찾아보기
- **문서 관리자**: 각 장에 현장 사진, 스크린샷, 회사 규칙을 덧붙여 내부 표준 문서로 확장

## 추천 학습 순서

1. 협동로봇과 UR 구조 이해
2. 하드웨어와 PolyScope 화면 구조 익히기
3. 첫 프로그램 작성
4. Waypoint / MoveJ / MoveL 감각 잡기
5. TCP와 Feature 교정
6. 위치변수이동으로 프로그램 유연하게 만들기
7. Payload / Singularity로 운전 안정성 높이기
8. URScript / Dashboard / Socket / RTDE로 자동화 확장

## 문서 맵

```{toctree}
:maxdepth: 2
:caption: 시작하기

start/cobot-overview
start/version-and-learning-path
start/ursim-first
```

```{toctree}
:maxdepth: 2
:caption: 기본 조작

basics/hardware
basics/polyscope-overview
basics/first-program
```

```{toctree}
:maxdepth: 2
:caption: 모션과 좌표

motion/waypoints-and-moves
motion/tcp
motion/frames-and-features
motion/variable-position-moves
```

```{toctree}
:maxdepth: 2
:caption: 안정 운전

stability/payload-and-cog
stability/singularity
```

```{toctree}
:maxdepth: 2
:caption: 자동화 확장

automation/urscript-basics
automation/communication-overview
automation/dashboard-server
automation/socket-communication
automation/rtde
```

```{toctree}
:maxdepth: 2
:caption: 부록

appendix/glossary
appendix/ports-and-interfaces
appendix/troubleshooting
appendix/official-resources
```

## 현장 반영 체크

- 실제 사용 로봇 모델명 표기
- PolyScope 5 / PolyScope X 사용 버전 명시
- 회사 표준 TCP / Feature 명명 규칙 추가
- 입출력 이름과 신호 방향 표기
- 위험구역, 저속검증 절차, 승인 흐름 추가
