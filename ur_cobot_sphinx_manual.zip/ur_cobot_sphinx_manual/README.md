# UR 협동로봇 입문 Sphinx 웹 매뉴얼

Universal Robots(UR) 협동로봇을 처음 쓰는 작업자/엔지니어를 위한 **학습형 웹 매뉴얼 초안**입니다.

이 프로젝트는 다음 방향으로 설계했습니다.

- **처음 보는 사람도 순서대로 따라갈 수 있게** `start -> basics -> motion -> stability -> automation` 흐름으로 구성
- **PolyScope 5 기준으로 설명**하되, 필요한 곳에는 PolyScope X 차이 메모를 추가
- **현장 커스터마이징이 쉽도록** Markdown(MyST) 기반으로 작성
- 나중에 팀 문서로 키우기 쉽도록 **부록 / 용어집 / 통신 표 / 트러블슈팅** 포함

## 폴더 구조

```text
ur_cobot_sphinx_manual/
  README.md
  requirements.txt
  Makefile
  make.bat
  docs/
    conf.py
    index.md
    start/
    basics/
    motion/
    stability/
    automation/
    appendix/
    _static/
```

## 빠르게 실행하기

### Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
.\make.bat html
```

빌드가 끝나면 아래 파일을 브라우저로 열면 됩니다.

```text
docs\_build\html\index.html
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
make html
```

빌드가 끝나면 아래 파일을 브라우저로 열면 됩니다.

```text
docs/_build/html/index.html
```

## 문서 커스터마이징 포인트

1. `docs/_static/img/`에 실제 현장 사진이나 URSim 캡처를 추가
2. 각 장의 예제 속도/가속도/신호명을 귀사 표준에 맞게 수정
3. `appendix/ports-and-interfaces.md`에 사용하는 PLC/비전/상위PC 규칙 추가
4. `appendix/troubleshooting.md`에 현장 빈출 에러를 계속 누적

## 추천 편집기

- VS Code
- Markdown Preview Enhanced 또는 기본 Markdown 미리보기
- Sphinx build를 같이 켜 두고 수정

## 작성 원칙

- 한 페이지에 **개념 1개 + 실습 1개 + 실수 포인트**를 넣는다.
- 초보자는 **왜 필요한지**를 먼저 설명하고, 상세 개념은 뒤로 보낸다.
- 실제 설비 적용 전에는 반드시 **최신 공식 안전 문서와 현장 위험성 평가**를 확인한다.

## 포함된 장

- 협동로봇이란?
- 하드웨어
- PolyScope
- 첫 프로그램
- 웨이포인트 및 이동 명령어
- TCP
- 좌표계 / Feature
- 위치변수이동
- 페이로드 / CoG
- 특이점
- URScript
- Dashboard / Socket / RTDE
- 용어집 / 포트표 / 트러블슈팅 / 공식 자료 링크
