# UR 협동로봇 입문 Sphinx 웹 매뉴얼

Universal Robots(UR) 협동로봇을 처음 쓰는 작업자와 엔지니어를 위한 **모던 스타일 Sphinx 웹 매뉴얼 템플릿**입니다.

이번 버전은 다음 방향으로 정리되어 있습니다.

- **학습형 문서 구조**: `start -> basics -> motion -> stability -> automation -> appendix`
- **모던 웹 문서 UI**: `pydata-sphinx-theme` + `sphinx-design` + 커스텀 CSS
- **쉬운 현장 커스터마이징**: Markdown 문서와 CSS만 수정해도 사내 표준 문서로 확장 가능
- **확장 가능한 구조**: 부록, 용어집, 포트 표, 트러블슈팅, 편집 가이드 포함

## 폴더 구조

```text
ur_cobot_sphinx_manual/
  README.md
  requirements.txt
  Makefile
  make.bat
  docs/
    conf.py
    index.md
    start/
    basics/
    motion/
    stability/
    automation/
    appendix/
    _static/
```

## 빠르게 실행하기

### Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
.\make.bat html
```

빌드가 끝나면 아래 파일을 브라우저로 열면 됩니다.

```text
docs\_build\html\index.html
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
make html
```

빌드가 끝나면 아래 파일을 브라우저로 열면 됩니다.

```text
docs/_build/html/index.html
```

## 무엇이 달라졌나?

### 디자인

- 상단에 **hero 랜딩 섹션** 추가
- 카드형 홈 화면과 사용자별 진입점 구성
- 다크 모드 대응 색상과 그림자 스타일 적용
- 로고 / 파비콘 / 버튼 / 카드 / 표 디자인 정리
- 검색 버튼과 테마 전환 버튼이 포함된 상단 네비게이션 구성

### 편집성

- `appendix/editing-guide.md`에 **문서 수정 방법** 추가
- `docs/index.md`만 수정해도 메뉴 구조 변경 가능
- `docs/_static/custom.css`에서 전체 톤앤매너 수정 가능
- `docs/_static/img/`에 현장 이미지 추가 가능

## 내용을 수정하려면

가장 자주 수정하는 파일은 아래 네 개입니다.

| 목적 | 파일 |
| --- | --- |
| 첫 화면 문구 / 카드 / 메뉴 | `docs/index.md` |
| 각 장 본문 | `docs/**/*.md` |
| 전체 디자인 | `docs/_static/custom.css` |
| 테마 설정 | `docs/conf.py` |

자세한 설명은 아래 문서를 보세요.

```text
docs/appendix/editing-guide.md
```

## 새 페이지 추가하는 가장 쉬운 방법

1. `docs/` 아래에 새 `.md` 파일 생성
2. 첫 줄에 `# 페이지 제목` 작성
3. `docs/index.md`의 적절한 `toctree`에 파일명 추가
4. 다시 빌드

예:

```md
# 안전 입문

안전 점검 순서와 저속 검증 절차를 정리합니다.
```

그리고 `docs/index.md`에:

```md
start/safety-basics
```

## 추천 편집기

- VS Code
- 기본 Markdown 미리보기
- Sphinx 빌드 터미널을 같이 띄워서 확인

## 선택 기능: 저장할 때마다 자동 미리보기

원하면 아래 패키지를 추가 설치할 수 있습니다.

```bash
pip install sphinx-autobuild
sphinx-autobuild docs docs/_build/html
```

## 커스터마이징 추천 순서

1. 메인 화면 문구와 카드 제목을 회사 교육 흐름에 맞게 수정
2. 하드웨어 / PolyScope 화면 캡처 추가
3. TCP / Feature / I/O 명명 규칙을 사내 표준으로 변경
4. PLC / 비전 / 상위 PC 통신 규칙 반영
5. 트러블슈팅 페이지에 현장 사례 누적

## 포함된 장

- 협동로봇이란?
- 하드웨어
- PolyScope
- 첫 프로그램
- 웨이포인트 및 이동 명령어
- TCP
- 좌표계 / Feature
- 위치변수이동
- 페이로드 / CoG
- 특이점
- URScript
- Dashboard / Socket / RTDE
- 용어집 / 포트표 / 트러블슈팅 / 공식 자료 링크
- 문서 수정 가이드
