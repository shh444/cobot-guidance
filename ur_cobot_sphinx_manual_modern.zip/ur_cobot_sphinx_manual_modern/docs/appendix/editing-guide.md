# 문서 수정 가이드

이 프로젝트는 **Sphinx + MyST Markdown** 기반입니다. 즉, 대부분의 수정은 Word나 전용 편집기가 아니라 **Markdown 파일과 CSS 파일**만 바꾸면 됩니다.

## 가장 빠른 수정 방법

1. `docs/` 폴더 안에서 바꾸고 싶은 `.md` 파일을 연다.
2. 문장을 수정하거나 표, 코드 블록, 이미지를 추가한다.
3. 터미널에서 HTML을 다시 빌드한다.
4. `docs/_build/html/index.html`을 새로고침한다.

## 어디를 수정해야 하나?

| 바꾸고 싶은 것 | 수정 파일 |
| --- | --- |
| 첫 화면 문구 / 카드 | `docs/index.md` |
| 각 장 본문 | `docs/start/*.md`, `docs/basics/*.md` 등 |
| 상단/사이드 메뉴 구조 | `docs/index.md` 안의 `toctree` |
| 전체 색감 / 카드 / 버튼 | `docs/_static/custom.css` |
| 테마 설정 | `docs/conf.py` |
| 로고 / 파비콘 | `docs/_static/brand-mark.svg`, `docs/_static/favicon.svg` |
| 이미지 추가 | `docs/_static/img/` |

## 새 페이지 추가하기

예를 들어 `안전 입문` 장을 하나 더 만들고 싶다면 이렇게 하면 됩니다.

### 1) 파일 만들기

`docs/start/safety-basics.md`

```md
# 안전 입문

이 장에서는 협동로봇을 처음 다룰 때 반드시 확인해야 하는 안전 포인트를 정리합니다.

## 핵심 체크

- 비상정지 위치 확인
- 보호정지 발생 시 대응 순서 확인
- 저속 검증 절차 확인
```

### 2) 메뉴에 연결하기

`docs/index.md`의 `시작하기` toctree에 아래 한 줄을 추가합니다.

```md
start/safety-basics
```

### 3) 빌드하기

Windows:

```powershell
.\make.bat html
```

macOS / Linux:

```bash
make html
```

### 4) 결과 확인하기

`docs/_build/html/index.html`을 열면 왼쪽 메뉴에 새 장이 나타납니다.

## 문장만 바꾸는 경우

예를 들어 `docs/motion/tcp.md` 파일에서 문장을 바로 고치면 됩니다.

```md
## 왜 TCP가 중요한가?

TCP가 잘못되면 MoveL 경로, Feature teaching, 위치변수이동 결과가 모두 어긋날 수 있습니다.
```

즉, **대부분의 내용 수정은 Markdown만 고치면 끝**입니다.

## 이미지 넣는 방법

### 1) 이미지 파일 복사

예: `docs/_static/img/tcp-setting-screen.png`

### 2) 본문에 삽입

```md
![TCP 설정 예시 화면](_static/img/tcp-setting-screen.png)
```

하위 폴더 문서에서 이미지를 넣을 때는 상대 경로를 맞춰야 합니다.

예: `docs/motion/tcp.md`에서는

```md
![TCP 설정 예시 화면](../_static/img/tcp-setting-screen.png)
```

## 내부 링크 거는 방법

다른 장으로 연결하려면 `doc` 역할을 쓰는 것이 가장 편합니다.

```md
자세한 내용은 {doc}`../motion/tcp` 장을 참고하세요.
```

또는 카드 링크에서는 아래처럼 씁니다.

````md
```{grid-item-card} TCP 보기
:link: motion/tcp
:link-type: doc
TCP 장으로 이동
```
````

## 카드, 버튼, 드롭다운 추가하기

이 프로젝트는 `sphinx-design`을 쓰도록 설정되어 있어서 카드형 레이아웃을 쉽게 넣을 수 있습니다.

### 카드 예시

````md
```{grid} 1 2 2 2
:gutter: 3

````{grid-item-card} MoveJ
관절 공간 이동에 적합합니다.
````

````{grid-item-card} MoveL
툴 끝단의 직선 경로에 적합합니다.
````
```
````

### 드롭다운 예시

````md
```{dropdown} 자주 하는 실수
- TCP를 교정하지 않고 MoveL만 반복 조정함
- Feature를 안 쓰고 모든 좌표를 Base 기준으로만 입력함
```
````

## 디자인을 바꾸고 싶을 때

### 테마 자체를 바꾸는 곳

`docs/conf.py`

여기서 다음 항목을 건드리면 전체 인상이 크게 바뀝니다.

- `html_theme`
- `html_theme_options`
- `html_logo`
- `html_favicon`
- `html_css_files`

### 세부 디자인을 바꾸는 곳

`docs/_static/custom.css`

여기서 아래 요소를 조정하면 됩니다.

- 첫 화면 hero 영역
- 카드 둥근 모서리 / 그림자
- 제목 크기와 간격
- 표 스타일
- 코드 블록 스타일
- 다크 모드 색상

## 로컬에서 계속 수정하면서 미리보기 하는 법

기본 방식은 매번 빌드하는 것입니다.

Windows:

```powershell
.\make.bat html
```

macOS / Linux:

```bash
make html
```

라이브 리로드가 필요하면 선택적으로 아래 패키지를 추가 설치한 뒤 사용하면 편합니다.

```bash
pip install sphinx-autobuild
sphinx-autobuild docs docs/_build/html
```

그러면 파일을 저장할 때마다 브라우저가 자동으로 갱신됩니다.

## 회사용으로 바꿀 때 추천하는 순서

1. 메인 화면 문구를 회사 교육 흐름에 맞게 수정
2. 실제 장비 사진과 티치 펜던트 캡처 추가
3. TCP / Feature / I/O 명명 규칙 반영
4. PLC / 비전 / 상위 PC 통신 예제 반영
5. 트러블슈팅 장에 현장 에러 사례 누적

## 자주 묻는 질문

### Markdown을 전혀 몰라도 수정할 수 있나?

가능합니다. 제목(`#`), 소제목(`##`), 목록(`-`) 정도만 알아도 대부분 수정할 수 있습니다.

### 문서를 여러 사람과 같이 관리하려면?

Git으로 버전 관리하는 것이 가장 좋습니다. 최소한 `docs/` 전체를 저장소로 관리하면 수정 이력 추적이 쉬워집니다.

### 디자인만 더 바꾸고 싶으면?

`custom.css`를 우선 수정하세요. 구조를 크게 바꾸지 않고도 카드, 색상, 간격, 제목 스타일을 거의 다 조정할 수 있습니다.
