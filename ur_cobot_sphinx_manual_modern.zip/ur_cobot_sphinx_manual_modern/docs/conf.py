project = "UR 협동로봇 입문 웹 매뉴얼"
author = "사용자 맞춤 초안"

extensions = [
    "myst_parser",
    "sphinx_copybutton",
    "sphinx_design",
]

source_suffix = {
    ".md": "markdown",
}

root_doc = "index"
language = "ko"
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]

html_theme = "pydata_sphinx_theme"
html_title = project
html_logo = "_static/brand-mark.svg"
html_favicon = "_static/favicon.svg"
html_static_path = ["_static"]
html_css_files = ["custom.css"]
html_last_updated_fmt = "%Y-%m-%d"
html_show_sourcelink = False

html_theme_options = {
    "announcement": "현장 반영 전에는 안전 문서와 위험성 평가 결과를 함께 확인하세요.",
    "show_nav_level": 2,
    "navigation_with_keys": True,
    "header_links_before_dropdown": 6,
    "navbar_start": ["navbar-logo"],
    "navbar_center": ["navbar-nav"],
    "navbar_persistent": ["search-button"],
    "navbar_end": ["theme-switcher"],
    "logo": {
        "text": "UR 협동로봇 매뉴얼",
    },
}

myst_enable_extensions = [
    "colon_fence",
    "deflist",
    "attrs_block",
    "attrs_inline",
]

myst_heading_anchors = 3
copybutton_prompt_text = r">>> |\.\.\. |\$ "
copybutton_prompt_is_regexp = True
