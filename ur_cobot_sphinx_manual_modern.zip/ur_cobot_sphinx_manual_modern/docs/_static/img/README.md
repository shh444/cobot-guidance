이 폴더에는 실제 현장 사진, URSim 캡처, TCP 설정 화면, Feature teaching 예시 이미지를 넣으면 됩니다.

추천 하위 구조 예시:

- `hardware/`
- `polyscope/`
- `motion/`
- `tcp/`
- `communication/`

로고와 파비콘은 `docs/_static/brand-mark.svg`, `docs/_static/favicon.svg`에 별도로 두었습니다.
