---
myst:
  html_meta:
    description: "Universal Robots 협동로봇 입문자를 위한 실습형 Sphinx 웹 매뉴얼"
---

<div class="hero-wrap">
  <div class="hero-grid">
    <div class="hero-copy">
      <div class="hero-badge-row">
        <span class="hero-badge">입문자 중심</span>
        <span class="hero-badge">PolyScope 5 / X</span>
        <span class="hero-badge">URSim 우선 학습</span>
      </div>
      <h1 class="hero-title">UR 협동로봇을 처음 쓰는 사람을 위한<br>실습형 웹 매뉴얼</h1>
      <p class="hero-lead">
        켜기, 움직이기, 기준 잡기, 변수화, 안정 운전, 통신까지를 하나의 학습 흐름으로 정리한
        Sphinx 기반 문서 템플릿입니다.
      </p>
      <div class="hero-actions">
        <a class="hero-button primary" href="start/cobot-overview.html">학습 시작하기</a>
        <a class="hero-button secondary" href="appendix/editing-guide.html">문서 수정 방법</a>
      </div>
    </div>

    <div class="hero-panel">
      <div class="eyebrow">recommended path</div>
      <h3>처음이라면 이 순서로 보세요</h3>
      <ol class="hero-list">
        <li><strong>협동로봇 이해</strong> — 구조, 용어, 버전 흐름 파악</li>
        <li><strong>기본 조작</strong> — 하드웨어, PolyScope, 첫 프로그램</li>
        <li><strong>모션과 좌표</strong> — Waypoint, MoveJ/MoveL, TCP, Feature</li>
        <li><strong>안정 운전</strong> — Payload, CoG, 특이점 회피</li>
        <li><strong>자동화 확장</strong> — URScript, Dashboard, Socket, RTDE</li>
      </ol>
      <p class="hero-mini">
        현장 실무자는 왼쪽 메뉴에서 TCP, Feature, Payload, Dashboard, RTDE 장만 바로 찾아봐도 됩니다.
      </p>
    </div>
  </div>
</div>

`````{grid} 1 2 2 4
:gutter: 3

````{grid-item-card} 10+ 장
:class-card: stat-card
처음 켜기부터 통신까지 한 흐름으로 정리했습니다.
````

````{grid-item-card} 6개 트랙
:class-card: stat-card
시작하기, 기본 조작, 모션, 안정 운전, 자동화, 부록으로 나뉩니다.
````

````{grid-item-card} 초보자용 문체
:class-card: stat-card
개념 설명보다 먼저 실습 흐름과 실수 포인트를 배치했습니다.
````

````{grid-item-card} 바로 수정 가능
:class-card: stat-card
Markdown과 CSS만 바꾸면 사내 표준 문서로 확장할 수 있습니다.
````
`````

:::{note}
이 문서는 **입문용 / 내부 교육용 초안**입니다. 실제 설비 반영 전에는 사용 중인 소프트웨어 버전의 공식 설명서, 안전 문서, 현장 위험성 평가 결과를 함께 확인하세요.
:::

## 학습 트랙

`````{grid} 1 1 2 3
:gutter: 3

````{grid-item-card} 시작하기
:link: start/cobot-overview
:link-type: doc
:class-card: section-link-card
협동로봇 개념, 버전 구분, URSim 진입 흐름을 정리합니다.
+++
협동로봇 / 버전 / URSim
````

````{grid-item-card} 기본 조작
:link: basics/hardware
:link-type: doc
:class-card: section-link-card
로봇 암, 컨트롤 박스, 티치 펜던트, PolyScope 화면 구조를 익힙니다.
+++
하드웨어 / PolyScope / 첫 프로그램
````

````{grid-item-card} 모션과 좌표
:link: motion/waypoints-and-moves
:link-type: doc
:class-card: section-link-card
Waypoint, MoveJ, MoveL, TCP, Feature, 위치변수이동을 한 흐름으로 배웁니다.
+++
Waypoint / TCP / Feature / Variable Move
````

````{grid-item-card} 안정 운전
:link: stability/payload-and-cog
:link-type: doc
:class-card: section-link-card
Payload/CoG 설정과 특이점 회피 방법을 현장 관점에서 설명합니다.
+++
Payload / CoG / Singularity
````

````{grid-item-card} 자동화 확장
:link: automation/urscript-basics
:link-type: doc
:class-card: section-link-card
URScript와 외부 장비 연동의 시작점을 잡아줍니다.
+++
URScript / Dashboard / Socket / RTDE
````

````{grid-item-card} 부록
:link: appendix/glossary
:link-type: doc
:class-card: section-link-card
용어집, 포트표, 트러블슈팅, 공식 자료 링크를 모아둡니다.
+++
용어집 / 포트 / 트러블슈팅
````
`````

## 사용자별 추천 진입점

`````{grid} 1 1 3 3
:gutter: 3

````{grid-item-card} 작업자 / 오퍼레이터
:class-card: role-card
처음엔 개념을 다 외우려 하지 말고 **하드웨어 → PolyScope → 첫 프로그램 → Waypoint** 순서로 익히세요.

추천 시작 장:
- {doc}`basics/hardware`
- {doc}`basics/polyscope-overview`
- {doc}`basics/first-program`
````

````{grid-item-card} 설비 / 자동화 엔지니어
:class-card: role-card
프로그램을 안정적으로 돌리는 데 필요한 **TCP, Feature, Payload, 통신** 위주로 읽으면 좋습니다.

추천 시작 장:
- {doc}`motion/tcp`
- {doc}`motion/frames-and-features`
- {doc}`stability/payload-and-cog`
- {doc}`automation/communication-overview`
````

````{grid-item-card} 문서 관리자 / 교육 담당자
:class-card: role-card
이 프로젝트는 Markdown 중심이라 **화면 캡처, 사내 규정, 표준 명명 규칙**을 얹기 쉽습니다.

추천 시작 장:
- {doc}`appendix/editing-guide`
- {doc}`appendix/troubleshooting`
- {doc}`appendix/ports-and-interfaces`
````
`````

## 문서 관리자에게

`````{grid} 1 1 2 2
:gutter: 3

````{grid-item-card} 내용을 바꾸려면
:link: appendix/editing-guide
:link-type: doc
:class-card: role-card
`docs/` 아래 Markdown 파일을 수정하면 됩니다. 새 페이지를 만들고 `index.md`의 toctree에 추가하면 메뉴에 바로 반영됩니다.
````

````{grid-item-card} 디자인을 바꾸려면
:class-card: role-card
바꿔야 할 파일은 네 군데입니다.

- 테마 설정: `docs/conf.py`
- CSS: `docs/_static/custom.css`
- 이미지: `docs/_static/img/`
- 로고 / 파비콘: `docs/_static/*.svg`
````
`````

## 현장 반영 체크리스트

```{dropdown} 실제 설비에 맞게 바꿔야 하는 항목
:open:

- 실제 사용 로봇 모델명 표기
- PolyScope 5 / PolyScope X 사용 버전 명시
- 회사 표준 TCP / Feature 명명 규칙 추가
- 입출력 이름과 신호 방향 표기
- 위험구역, 저속검증 절차, 승인 흐름 추가
- PLC, 비전, 상위 PC와의 통신 규칙 추가
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 시작하기

start/cobot-overview
start/version-and-learning-path
start/ursim-first
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 기본 조작

basics/hardware
basics/polyscope-overview
basics/first-program
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 모션과 좌표

motion/waypoints-and-moves
motion/tcp
motion/frames-and-features
motion/variable-position-moves
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 안정 운전

stability/payload-and-cog
stability/singularity
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 자동화 확장

automation/urscript-basics
automation/communication-overview
automation/dashboard-server
automation/socket-communication
automation/rtde
```

```{toctree}
:hidden:
:maxdepth: 2
:caption: 부록

appendix/glossary
appendix/ports-and-interfaces
appendix/troubleshooting
appendix/official-resources
appendix/editing-guide
```
